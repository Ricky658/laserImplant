<div class="offset-md-1 col-md-10 menu-pagina">
    <div class="row">
        <div class="col-md-3">
            
        </div>
        <div class="col-md-9">
            <ul>
                <li><a href="{{url('')}}">INICIO</a></li>
                <li><a href="{{url('medicos')}}">DOCTORES</a></li>
                <li><a href="{{url('testimonios')}}">TESTIMONIOS</a></li>
                <li><a href="{{url('cambios')}}">ANTES Y DESPÚES</a></li>
                <li><a href="{{url('indicaciones')}}">INDICACIONES</a></li>
                <li><a href="{{url('clinica')}}">CLÍNICA</a></li>
            </ul>
        </div>
    </div>
</div>