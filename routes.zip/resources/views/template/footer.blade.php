<div class="col-md-12 footer">
    <ul>
        <li><a href="#home"><i class="fa-solid fa-location-dot"></i><label class="aparecer">Encuéntranos</label></a></li>
        <li><a href="#home"><i class="fa-brands fa-facebook"></i><label class="aparecer">Me gusta</label></a></li>
        <li><a href="#home"><i class="fa-brands fa-instagram"></i><label class="aparecer">Comparte</label></a></li>
        <li><a href="#home"><i class="fa-brands fa-tiktok"></i><label class="aparecer">Síguenos</label></a></li>
        <li><a href="#home"><i class="fa-brands fa-youtube"></i><label class="aparecer">Síguenos</label></a></li>
    </ul>
</div>